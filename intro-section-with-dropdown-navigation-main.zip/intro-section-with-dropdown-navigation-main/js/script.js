
let navbar=document.querySelector(".navbar");
let overlay=document.querySelector(".overlay");
let features=document.querySelector("#features");
let company=document.querySelector("#company");
let features_dropdown=document.querySelector(".features-dropdown");
let company_dropdown=document.querySelector(".company-dropdown");
let main_menu=document.querySelector(".main-menu");
let icon_menu=document.querySelector(".icon-menu");
let icon_close=document.querySelector("#icon-close-menu");
let arrow_feature=document.querySelector("#arrow-features");
let arrow_company=document.querySelector("#arrow_company");
icon_menu.addEventListener("click",(e)=>{
    navbar.style.display="flex";
    console.log("menu was clicked");
    
    icon_close.addEventListener("click",(e)=>{
      navbar.style.display="none";  
    })
})


const media=window.matchMedia('(max-width:890px)');
media.addEventListener("change",(e)=>{
    if(e.matches){
        navbar.style.display="none";  
    }else{
        navbar.style.display="flex";
    }
})
